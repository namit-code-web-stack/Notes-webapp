let r1=document.getElementById("r1")
let r2=document.getElementById("r2")
let r3=document.getElementById("r3")
let button=document.getElementById("button")
let radio=document.getElementsByClassName("radio")
let title=document.getElementById("textbox")
let message=document.getElementById("message")
let box1=document.getElementById("box1")
let container=document.getElementById("container")


//disable all
message.disabled=true;
title.disabled=true;
r1.disabled=true;
r2.disabled=true;
r3.disabled=true;

//enable
let img=document.getElementById("img1")
img.addEventListener("click",()=>{
    message.disabled=false;
   title.disabled=false;
   r1.disabled=false;
   r2.disabled=false;
   r3.disabled=false; 
   title.style.backgroundColor="#fcdada"
   message.style.backgroundColor="#fcdada"
})

//store mssg
let mssg_store=""
let title_store=""

   button.addEventListener("click",()=>{
   let anyradio=r1.checked||r2.checked||r3.checked;
if(message.value !==""&&title.value !==""&&anyradio){

   //div create
   let div=document.createElement('div')
  let id=Math.floor(Math.random()*10)+1
    div.id="box"+id
   div.className="box"
   div.style.height="auto"
   div.style.wordWrap = "break-word"; 
   div.style.overflow="auto"
   div.style.width="30vh";
   div.style.border="1.5vh white solid"
   div.style.borderRadius= "8vh"

   div.innerHTML=
      `<h2 style="font-size :3vh;font-weight:bold;margin:2vh;text-align:center;color:white ;text-shadow: 1px 1px 2px black">${title.value.toUpperCase()}</h2>
      <h3 style="font-size :2vh;margin:2vh;font-weight:italic">${message.value}</h3>
        <h6 style="text-align: end;font-size: 1.5vh;line-height: 0;margin-right:4vh;color:blue;"> ${new Date().getDate()}/${new Date().getMonth() + 1}/${new Date().getFullYear()}</h6>
  <h6 style="text-align: end;font-size: 1.5vh ;margin-bottom:2vh;line-height: 0;margin-right:4vh;color:blue"> ${new Date().getHours()}-${new Date().getMinutes()}-${new Date().getSeconds()}</h6>`
 
  //delete
let del_img=document.querySelector('.drop')
let can_img=document.querySelector('.cancel')


div.addEventListener("mouseup",(event)=>{
  if (div.querySelector('.delete-section')) return;
      let delete1=document.createElement('section')
      delete1.className="delete-section"


   //img1
      let img1=document.createElement('img')
      img1.src="./x-circle-fill.svg"
      img1.id="drop1"
      img1.className="cancel"

      //img2
      let img2=document.createElement('img')
      img2.src="./trash.svg"
      img2.id="drop2"
      img2.className="drop"
      delete1.appendChild(img1)
      delete1.appendChild(img2)
      div.appendChild(delete1)

      //cancel button
      img1.addEventListener("click",(event1)=>{
      event1.stopPropagation();
      delete1.remove()
      updatelocal()
   })

    img2.addEventListener("click",(event1)=>{
      event1.stopPropagation();
      div.remove()
      updatelocal()
   })
   

  div.appendChild(delete1);
  updatelocal()
})



//cancel img

  

   container.append(div)
   
   if(r1.checked){
      div.style.backgroundColor="green"
   }
   else if(r2.checked){
      div.style.backgroundColor="yellow"
   }
   else{
       div.style.backgroundColor="red"
   }
   message.value=""
   title.value=""
   r1.checked=false;
   r2.checked=false;
   r3.checked=false;






   // saved local storage
function updatelocal() {
   
   let store=document.getElementsByClassName('box')
   let boxesHTML=[]
   for (let i = 0; i < store.length; i++) {
      boxesHTML.push(store[i].outerHTML);
   }
   localStorage.setItem("store", JSON.stringify(boxesHTML));
}}

else{
   alert("fil proper")
}
})

//help-section
let icon=document.querySelector('#symbol');
icon.addEventListener("click",()=>{
   window.location.href="./help.html"

})


// retrive local storage
window.addEventListener("load", () => {
  let saved = JSON.parse(localStorage.getItem("store"));
  if (saved) {
    for (let a of saved) {
      let temp = document.createElement("div");
      temp.innerHTML = a;
      let div = temp.firstElementChild;
      container.appendChild(div);

      // Bind mouseup for restored box
      div.addEventListener("mouseup", (event) => {
        if (div.querySelector(".delete-section")) return;

        let delete1 = document.createElement("section");
        delete1.className = "delete-section";

        let img1 = document.createElement("img");
        img1.src = "./x-circle-fill.svg";
        img1.className = "cancel";

        let img2 = document.createElement("img");
        img2.src = "./trash.svg";
        img2.className = "drop";

        delete1.appendChild(img1);
        delete1.appendChild(img2);
        div.appendChild(delete1);

        // Cancel
        img1.addEventListener("click", (event1) => {
          event1.stopPropagation();
          delete1.remove();
          updatelocal();
        });

        // Delete
        img2.addEventListener("click", (event1) => {
          event1.stopPropagation();
          div.remove();
          updatelocal();
        });
      });
    }
  }
});




localStorage.clear()